# Better Membean by Carlos Quiñones


This extension applies a theme to your membean sessions.<br/>

# Examples

<img width=" 500px" heigth = "2500px" src = "https://github.com/CarlosQR/betterMembean/blob/main/example.PNG"> <img width=" 500px" heigth = "2500px" src = "https://github.com/CarlosQR/betterMembean/blob/main/example2.PNG"><br/>

# Basic Information:



1.Only use the extension once you are in a membean session or on the screen that lets you chose the length of your session.To use the extension click on the icon on your top rigth <br /> 
<img width=" 30px" heigth = "30px" src = "https://github.com/CarlosQR/betterMembean/blob/main/images/Icon.PNG"><br/>
2.The Plus button alows you to create your own theme that will then be saved for later use.You have a maximum of 9 theme slots availabe. <br /> 
<img width=" 30px" heigth = "30px" src = "kisspng-computer-icons-download-button-symbol-plus-5abd9e3f0d1281.9002311215223762550536-removebg-preview.png"><br/>
3.To set a background image you must first have the url for the image, which can be found by left clicking the source of the image and and clicking copy image adress. <br /> 

3.The Edit Theme button is found beside the Plus button and once clicked you will be put into edit mode, in which you can then click on the theme you want to edit.<br/>
<img width=" 30px" heigth = "30px" src = "edit.png"><br/>
4.Download the zip file to use!! : <br/>
https://github.com/CarlosQR/betterMembean/blob/main/betterMembean.zip


# Warning
The extension will work while on this page, editing or creating themes should be done while here or else problems may arise<br/>
<img width=" 500px" heigth = "2500px" src = "https://github.com/CarlosQR/betterMembean/blob/main/images/Training.PNG"><br/>
# How to Load a Chomre Extension:

1.Go to chrome://extensions/<br /> 
2.On the top left click Load Unpacked <br /> 
3.And choose the unziped folder of the extension


